"""Step 4: fine-tune RF-DETR-Seg on a split produced by step 3.

RF-DETR-Seg = DINOv2 ViT backbone (windowed attention) + multi-scale projector + deformable-attention
DETR decoder + a lightweight mask head (query embeddings dotted with a 1/4-resolution pixel embedding).
Starts from COCO-pretrained weights; the backbone gets a lower learning rate than the decoder.

Example
  python 04_train.py --split data/splits/in_domain --variant small --epochs 50
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=Path, required=True)
    ap.add_argument("--variant", choices=["nano", "small", "medium", "large"], default="small")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--grad-accum", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--resolution", type=int, default=None, help="must be divisible by 24 for Seg models")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    import rfdetr

    cls = {"nano": rfdetr.RFDETRSegNano, "small": rfdetr.RFDETRSegSmall,
           "medium": rfdetr.RFDETRSegMedium, "large": rfdetr.RFDETRSegLarge}[args.variant]
    kwargs = {"resolution": args.resolution} if args.resolution else {}
    model = cls(**kwargs)

    out = args.out or Path("runs") / f"{args.split.name}_{args.variant}"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    model.train(
        dataset_dir=str(args.split),
        epochs=args.epochs,
        batch_size=args.batch_size,
        grad_accum_steps=args.grad_accum,
        lr=args.lr,
        output_dir=str(out),
    )
    meta = {"split": str(args.split), "variant": args.variant, "epochs": args.epochs,
            "batch_size": args.batch_size, "grad_accum": args.grad_accum, "lr": args.lr,
            "resolution": args.resolution, "train_hours": round((time.time() - t0) / 3600, 2)}
    (out / "run_meta.json").write_text(json.dumps(meta, indent=2))
    print("done:", meta, "->", out)


if __name__ == "__main__":
    main()
