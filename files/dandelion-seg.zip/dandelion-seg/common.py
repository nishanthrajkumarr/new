"""Shared helpers for the dandelion instance-segmentation experiments.

Everything here is CPU-only (numpy + OpenCV) so it can be unit-tested without a GPU.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

# Category ids follow COCO convention (1-based). Order matters: RF-DETR maps class_id -> class_names by this order.
CATEGORIES = [
    {"id": 1, "name": "flower", "supercategory": "dandelion"},
    {"id": 2, "name": "seedhead", "supercategory": "dandelion"},
    {"id": 3, "name": "rosette", "supercategory": "dandelion"},
]
NAME_TO_ID = {c["name"]: c["id"] for c in CATEGORIES}

# SAM 3 concept prompts per class. Several phrasings per class; detections are merged.
PROMPTS = {
    "flower": ["yellow dandelion flower"],
    "seedhead": ["dandelion seed head", "white dandelion puffball"],
    "rosette": ["dandelion leaf rosette", "dandelion leaves"],
}


@dataclass
class Instance:
    category: str
    mask: np.ndarray  # bool HxW
    score: float


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = np.logical_and(a, b).sum()
    if inter == 0:
        return 0.0
    return float(inter) / float(np.logical_or(a, b).sum())


def merge_instances(instances: list[Instance], iou_thr: float = 0.7) -> list[Instance]:
    """Greedy mask-NMS across all classes and prompts: keep the highest-scoring of any overlapping pair.

    Overlap across *different* classes is resolved the same way, because one plant part should get one label.
    """
    kept: list[Instance] = []
    for inst in sorted(instances, key=lambda i: i.score, reverse=True):
        if inst.mask.sum() == 0:
            continue
        if all(mask_iou(inst.mask, k.mask) < iou_thr for k in kept):
            kept.append(inst)
    return kept


def mask_to_polygons(mask: np.ndarray, min_area: float = 16.0, epsilon_frac: float = 0.002) -> list[list[float]]:
    """Binary mask -> list of COCO polygons (flattened x,y lists). Small fragments are dropped."""
    m = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    polys: list[list[float]] = []
    for c in contours:
        if cv2.contourArea(c) < min_area:
            continue
        eps = epsilon_frac * cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, eps, True).reshape(-1, 2)
        if len(approx) < 3:
            continue
        polys.append([float(v) for xy in approx for v in xy])
    return polys


def polygons_to_bbox(polys: list[list[float]]) -> list[float]:
    pts = np.concatenate([np.asarray(p, dtype=np.float64).reshape(-1, 2) for p in polys])
    x0, y0 = pts.min(axis=0)
    x1, y1 = pts.max(axis=0)
    return [float(x0), float(y0), float(x1 - x0), float(y1 - y0)]


def polygons_area(polys: list[list[float]], h: int, w: int) -> float:
    canvas = np.zeros((h, w), np.uint8)
    for p in polys:
        cv2.fillPoly(canvas, [np.asarray(p, np.int32).reshape(-1, 2)], 1)
    return float(canvas.sum())


def crown_estimate(mask: np.ndarray) -> tuple[float, float]:
    """Initial crown (taproot) proposal for a rosette: the mask centroid.

    Rosette leaves radiate from the crown, so the centroid is a reasonable first guess; annotators then correct it.
    """
    ys, xs = np.nonzero(mask)
    return float(xs.mean()), float(ys.mean())


def empty_coco() -> dict:
    return {
        "info": {"description": "Dandelion instance segmentation (auto-labelled with SAM 3, see README)"},
        "licenses": [],
        "images": [],
        "annotations": [],
        "categories": CATEGORIES,
    }


def add_image(coco: dict, file_name: str, h: int, w: int, extra: dict | None = None) -> int:
    img_id = len(coco["images"]) + 1
    rec = {"id": img_id, "file_name": file_name, "height": h, "width": w}
    if extra:
        rec.update(extra)
    coco["images"].append(rec)
    return img_id


def add_instance(coco: dict, img_id: int, inst: Instance, h: int, w: int) -> bool:
    polys = mask_to_polygons(inst.mask)
    if not polys:
        return False
    ann = {
        "id": len(coco["annotations"]) + 1,
        "image_id": img_id,
        "category_id": NAME_TO_ID[inst.category],
        "segmentation": polys,
        "bbox": polygons_to_bbox(polys),
        "area": polygons_area(polys, h, w),
        "iscrowd": 0,
        "score": round(float(inst.score), 4),  # auto-label confidence, kept for review triage
    }
    if inst.category == "rosette":
        cx, cy = crown_estimate(inst.mask)
        ann["crown"] = [round(cx, 1), round(cy, 1)]
        ann["crown_verified"] = False
    coco["annotations"].append(ann)
    return True


def save_json(obj: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj))


def load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text())
