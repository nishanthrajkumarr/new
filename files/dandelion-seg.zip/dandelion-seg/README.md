# Dandelion instance segmentation with RF-DETR-Seg

Experiment kit for the DandeBot perception study. It does four things:

1. **Collects** a multi-source pool of dandelion images with provenance.
2. **Auto-labels** them with **SAM 3** concept prompts.
3. **Fine-tunes** **RF-DETR-Seg**, a real-time DINOv2-based detection transformer, on group-aware splits.
4. **Evaluates** against the zero-shot SAM 3 teacher.

| Step | Script | Needs GPU |
|---|---|---|
| 1. Collect images (iNaturalist CC0/CC-BY, TF flowers, your robot frames) | `01_collect.py` | no |
| 2. Auto-label with SAM 3 (flower / seed head / rosette + crown proposal) | `02_autolabel_sam3.py` | yes |
| 3. Group-aware splits (in-domain; cross-domain = test on robot frames) | `03_make_splits.py` | no |
| 4. Fine-tune RF-DETR-Seg | `04_train.py` | yes |
| 5. Evaluate (mask AP, per-class AP, crown error, latency) and make figures | `05_evaluate.py` | yes |
| 6. Zero-shot SAM 3 baseline on the same test set | `06_eval_sam3_baseline.py` | yes |

## Setup (Colab or a CUDA workstation)

```bash
pip install -r requirements.txt
git clone https://github.com/facebookresearch/sam3 && pip install -e sam3
huggingface-cli login          # after access to facebook/sam3 is approved on Hugging Face
```

Budget: about 1–2 h on a T4 for ~2,000 images and 50 epochs of `RFDETRSegSmall`. It is faster on an A100.

## Run

```bash
bash run_all.sh                        # web data only
bash run_all.sh /path/to/robot_frames  # adds your DandeBot captures as a held-out test domain
```

Sub-folders under your frames folder are treated as capture sessions. Images from one session never land in both train and test.

## Human verification (do not skip)

Auto-labels train the model, but **test labels must be checked by a person**. If they aren't, you are measuring agreement with SAM 3, not accuracy.

1. Open `data/splits/in_domain/test` (and `cross_domain/test`) in CVAT or Roboflow.
2. Fix the masks and classes, and move each rosette's `crown` point onto the true crown. Set `crown_verified: true`.
3. Export COCO to `data/verified_test.coco.json`.
4. Re-run with `VERIFIED=data/verified_test.coco.json bash run_all.sh`, or run steps 3 and 5 alone.

Report the time this took and the fraction of masks you had to edit. It is a useful result in its own right, because it measures how good the auto-labeller really is.

## What ends up in `results/`

- `metrics.json`: mask AP, AP50, AP75, AP_small, per-class AP, box AP, crown error (px), latency.
- `results_table.png`, `per_class.png`, `qualitative.png`: slide-ready figures.
- `sam3_zero_shot/metrics.json`: the teacher baseline.

Latency printed here is for the GPU you trained on. For the deployment number, export with `model.export()` and time it on the Jetson with TensorRT FP16.

## Data licences

iNaturalist photos are filtered to CC0 and CC-BY. Their attributions are kept in `data/raw/manifest.csv`, and you must credit them if you publish example images. The TensorFlow flower photos are CC-BY. Don't redistribute the raw pool. Share the manifest instead.
