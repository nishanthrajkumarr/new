"""Step 6 (baseline): zero-shot SAM 3 on the same human-verified test set.

This is the teacher. Comparing it with the fine-tuned RF-DETR-Seg student answers the deployment question:
how much accuracy do we keep when we go from an ~840M-parameter text-prompted model to a ~34M real-time one?
Writes results/sam3_zero_shot/metrics.json
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from pycocotools import mask as mask_utils
from pycocotools.coco import COCO

from common import NAME_TO_ID, PROMPTS, Instance, merge_instances

import importlib

evaluate = importlib.import_module("05_evaluate")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=Path, required=True)
    ap.add_argument("--score", type=float, default=0.3)
    ap.add_argument("--out", type=Path, default=Path("results/sam3_zero_shot"))
    args = ap.parse_args()

    from sam3.model.sam3_image_processor import Sam3Processor
    from sam3.model_builder import build_sam3_image_model

    processor = Sam3Processor(build_sam3_image_model())
    test_dir = args.split / "test"
    gt = COCO(str(test_dir / "_annotations.coco.json"))
    dets, lat = [], []
    for img_id in gt.getImgIds():
        info = gt.loadImgs(img_id)[0]
        img = Image.open(test_dir / info["file_name"]).convert("RGB")
        t0 = time.perf_counter()
        state = processor.set_image(img)
        insts = []
        for cls, phrases in PROMPTS.items():
            for p in phrases:
                o = processor.set_text_prompt(state=state, prompt=p)
                if o["masks"] is None or len(o["scores"]) == 0:
                    continue
                masks = o["masks"].detach().float().cpu().numpy()
                masks = masks[:, 0] if masks.ndim == 4 else masks
                for m, s in zip(masks > 0.5, o["scores"].detach().float().cpu().numpy()):
                    if s >= args.score:
                        insts.append(Instance(cls, m, float(s)))
        insts = merge_instances(insts)
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        lat.append((time.perf_counter() - t0) * 1000)
        for inst in insts:
            rle = mask_utils.encode(np.asfortranarray(inst.mask.astype(np.uint8)))
            rle["counts"] = rle["counts"].decode("ascii")
            dets.append({"image_id": img_id, "category_id": NAME_TO_ID[inst.category], "segmentation": rle, "score": inst.score})

    seg, ev = evaluate.run_coco_eval(gt, dets, "segm")
    metrics = {"model": "SAM 3 zero-shot (text prompts)", "mask": seg,
               "mask_AP_per_class": evaluate.per_class_ap(ev) if ev else {},
               "latency_ms_median": round(float(np.median(lat)), 1) if lat else None}
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
