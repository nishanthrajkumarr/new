"""Step 2: auto-label every image with SAM 3 concept prompts -> COCO instance masks.

SAM 3 (Meta, Nov 2025) takes a noun phrase and returns masks for *all* matching instances.
We prompt each class with a few phrasings (common.PROMPTS), merge overlapping masks across prompts/classes,
and write one COCO file for the whole pool. Rosettes also get a crown proposal (mask centroid) for annotators to fix.

Requires: access to the gated SAM 3 checkpoints on Hugging Face (`huggingface-cli login` after approval) and a GPU.

Output
  data/autolabel/annotations.coco.json
  data/autolabel/review/*.jpg   (random overlays for spot-checking)
"""
from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm

from common import PROMPTS, Instance, add_image, add_instance, empty_coco, merge_instances, save_json

COLORS = {"flower": (255, 196, 0), "seedhead": (90, 170, 255), "rosette": (60, 200, 90)}


def to_numpy_masks(masks) -> np.ndarray:
    m = masks.detach().float().cpu().numpy() if torch.is_tensor(masks) else np.asarray(masks)
    if m.ndim == 4:  # N,1,H,W
        m = m[:, 0]
    return m > 0.5


def overlay(img: np.ndarray, insts: list[Instance]) -> np.ndarray:
    out = img.copy()
    for inst in insts:
        color = np.array(COLORS[inst.category], np.uint8)
        out[inst.mask] = (0.45 * out[inst.mask] + 0.55 * color).astype(np.uint8)
        cnts, _ = cv2.findContours(inst.mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(out, cnts, -1, tuple(int(c) for c in color), 2)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=Path, default=Path("data/raw"))
    ap.add_argument("--out", type=Path, default=Path("data/autolabel"))
    ap.add_argument("--score", type=float, default=0.5, help="min SAM 3 score to keep an instance")
    ap.add_argument("--review", type=int, default=60, help="number of overlay images to save for spot-checks")
    args = ap.parse_args()

    from sam3.model.sam3_image_processor import Sam3Processor
    from sam3.model_builder import build_sam3_image_model

    model = build_sam3_image_model()
    processor = Sam3Processor(model)

    with open(args.raw / "manifest.csv") as f:
        rows = list(csv.DictReader(f))

    coco = empty_coco()
    review_ids = set(random.Random(0).sample(range(len(rows)), min(args.review, len(rows))))
    stats = {k: 0 for k in PROMPTS}
    for idx, row in enumerate(tqdm(rows, desc="SAM 3")):
        img = Image.open(args.raw / row["file"]).convert("RGB")
        w, h = img.size
        state = processor.set_image(img)
        insts: list[Instance] = []
        for cls, phrases in PROMPTS.items():
            for phrase in phrases:
                out = processor.set_text_prompt(state=state, prompt=phrase)
                if out["masks"] is None or len(out["scores"]) == 0:
                    continue
                masks = to_numpy_masks(out["masks"])
                scores = out["scores"].detach().float().cpu().numpy() if torch.is_tensor(out["scores"]) else np.asarray(out["scores"])
                for m, s in zip(masks, scores):
                    if s >= args.score:
                        insts.append(Instance(cls, m.astype(bool), float(s)))
        insts = merge_instances(insts)
        img_id = add_image(coco, row["file"], h, w, {"source": row["source"], "group": row["group"]})
        for inst in insts:
            if add_instance(coco, img_id, inst, h, w):
                stats[inst.category] += 1
        if idx in review_ids:
            vis = overlay(np.array(img), insts)
            (args.out / "review").mkdir(parents=True, exist_ok=True)
            Image.fromarray(vis).save(args.out / "review" / Path(row["file"]).name)

    save_json(coco, args.out / "annotations.coco.json")
    print(f"images={len(coco['images'])} instances={len(coco['annotations'])} per-class={stats}")


if __name__ == "__main__":
    main()
