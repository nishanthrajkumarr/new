#!/usr/bin/env bash
# End-to-end run on a single GPU (Colab T4/A100 or a workstation).
# Usage: bash run_all.sh [path/to/own/robot/frames]
set -euo pipefail

OWN=${1:-}

python 01_collect.py --inat 1500 ${OWN:+--own "$OWN"}
python 02_autolabel_sam3.py

echo
echo ">>> STOP: verify the test images before reporting numbers (README, 'Human verification')."
echo ">>> Re-run step 3 with --test-coco data/verified_test.coco.json once that file exists."
echo

python 03_make_splits.py ${VERIFIED:+--test-coco "$VERIFIED"}

python 04_train.py --split data/splits/in_domain --variant small --epochs 50
python 05_evaluate.py --split data/splits/in_domain --run runs/in_domain_small --variant small
python 06_eval_sam3_baseline.py --split data/splits/in_domain

if [ -d data/splits/cross_domain ]; then
  python 04_train.py --split data/splits/cross_domain --variant small --epochs 50
  python 05_evaluate.py --split data/splits/cross_domain --run runs/cross_domain_small --variant small
fi

echo "Results in ./results — send that folder back to drop into the slides."
