"""Step 1: assemble a multi-source dandelion image pool with provenance.

Sources
  inat        iNaturalist research-grade observations of Taraxacum officinale, CC0 / CC-BY photos only.
              Real backyards, lawns and verges: rosettes, flowers and seed heads in context.
  tf_flowers  TensorFlow "flower_photos" dandelion folder (CC-BY, close-up flowers).
  own         Optional: frames from your own robot / phone captures (--own DIR). Kept as a separate domain.

Output
  data/raw/<source>/<image>.jpg
  data/raw/manifest.csv   (file, source, group, license, attribution, url)

`group` is what the splitter uses to keep near-duplicate images out of both train and test:
iNaturalist -> observer id, tf_flowers -> one group per photo, own -> capture session (sub-folder name).
"""
from __future__ import annotations

import argparse
import csv
import io
import shutil
import tarfile
import time
from pathlib import Path

import requests
from PIL import Image
from tqdm import tqdm

INAT_API = "https://api.inaturalist.org/v1/observations"
TF_FLOWERS = "https://storage.googleapis.com/download.tensorflow.org/example_images/flower_photos.tgz"
UA = {"User-Agent": "dandelion-seg-research/1.0 (academic use)"}


def save_rgb(content: bytes, dst: Path, max_side: int = 1280) -> tuple[int, int] | None:
    try:
        im = Image.open(io.BytesIO(content)).convert("RGB")
    except Exception:
        return None
    im.thumbnail((max_side, max_side))
    dst.parent.mkdir(parents=True, exist_ok=True)
    im.save(dst, quality=92)
    return im.size


def collect_inat(out: Path, rows: list[dict], limit: int, per_observer: int) -> None:
    per_obs_count: dict[str, int] = {}
    page, got = 1, 0
    pbar = tqdm(total=limit, desc="iNaturalist")
    while got < limit:
        params = {
            "taxon_name": "Taraxacum officinale",
            "quality_grade": "research",
            "photo_license": "cc0,cc-by",
            "photos": "true",
            "per_page": 200,
            "page": page,
            "order_by": "id",
            "order": "desc",
        }
        r = requests.get(INAT_API, params=params, headers=UA, timeout=60)
        r.raise_for_status()
        results = r.json().get("results", [])
        if not results:
            break
        for obs in results:
            observer = str(obs.get("user", {}).get("id", "unknown"))
            if per_obs_count.get(observer, 0) >= per_observer:
                continue  # cap per observer so no single garden dominates
            for photo in obs.get("photos", [])[:1]:
                lic = (photo.get("license_code") or "").lower()
                if lic not in {"cc0", "cc-by"}:
                    continue
                url = photo["url"].replace("square", "large")
                fname = f"inat_{obs['id']}_{photo['id']}.jpg"
                try:
                    resp = requests.get(url, headers=UA, timeout=60)
                    resp.raise_for_status()
                except requests.RequestException:
                    continue
                if save_rgb(resp.content, out / "inat" / fname) is None:
                    continue
                rows.append({
                    "file": f"inat/{fname}", "source": "inat", "group": f"inat_user_{observer}",
                    "license": lic, "attribution": photo.get("attribution", ""), "url": f"https://www.inaturalist.org/observations/{obs['id']}",
                })
                per_obs_count[observer] = per_obs_count.get(observer, 0) + 1
                got += 1
                pbar.update(1)
                time.sleep(0.3)  # be polite to iNaturalist
            if got >= limit:
                break
        page += 1
        time.sleep(1.0)
    pbar.close()


def collect_tf_flowers(out: Path, rows: list[dict], cache: Path) -> None:
    cache.mkdir(parents=True, exist_ok=True)
    tgz = cache / "flower_photos.tgz"
    if not tgz.exists():
        with requests.get(TF_FLOWERS, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(tgz, "wb") as f:
                shutil.copyfileobj(r.raw, f)
    with tarfile.open(tgz) as tf:
        members = [m for m in tf.getmembers() if m.isfile() and "/dandelion/" in m.name and m.name.endswith(".jpg")]
        for m in tqdm(members, desc="tf_flowers"):
            data = tf.extractfile(m).read()
            fname = "tf_" + Path(m.name).name
            if save_rgb(data, out / "tf_flowers" / fname) is None:
                continue
            rows.append({
                # independent Flickr photos, so each image is its own group
                "file": f"tf_flowers/{fname}", "source": "tf_flowers", "group": f"tf_{Path(fname).stem}",
                "license": "cc-by", "attribution": "TensorFlow flower_photos (see LICENSE.txt in archive)", "url": TF_FLOWERS,
            })


def collect_own(src: Path, out: Path, rows: list[dict]) -> None:
    exts = {".jpg", ".jpeg", ".png"}
    for p in tqdm(sorted(src.rglob("*")), desc="own"):
        if p.suffix.lower() not in exts:
            continue
        session = p.parent.name if p.parent != src else "session0"
        fname = f"own_{session}_{p.stem}.jpg"
        if save_rgb(p.read_bytes(), out / "own" / fname) is None:
            continue
        rows.append({"file": f"own/{fname}", "source": "own", "group": f"own_{session}",
                     "license": "own", "attribution": "self", "url": ""})


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=Path("data/raw"))
    ap.add_argument("--inat", type=int, default=1500, help="max iNaturalist images (0 to skip)")
    ap.add_argument("--per-observer", type=int, default=5)
    ap.add_argument("--no-tf-flowers", action="store_true")
    ap.add_argument("--own", type=Path, default=None, help="folder of your own captures (sub-folders = sessions)")
    args = ap.parse_args()

    rows: list[dict] = []
    if args.inat > 0:
        collect_inat(args.out, rows, args.inat, args.per_observer)
    if not args.no_tf_flowers:
        collect_tf_flowers(args.out, rows, args.out.parent / "cache")
    if args.own:
        collect_own(args.own, args.out, rows)

    args.out.mkdir(parents=True, exist_ok=True)
    with open(args.out / "manifest.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["file", "source", "group", "license", "attribution", "url"])
        w.writeheader()
        w.writerows(rows)
    by_src: dict[str, int] = {}
    for r in rows:
        by_src[r["source"]] = by_src.get(r["source"], 0) + 1
    print("collected:", by_src, "groups:", len({r['group'] for r in rows}))


if __name__ == "__main__":
    main()
