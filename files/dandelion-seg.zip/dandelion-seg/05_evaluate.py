"""Step 5: evaluate a trained RF-DETR-Seg checkpoint and write slide-ready results.

Reports (on the split's TEST set, which should be human-verified):
  - COCO mask AP, AP50, AP75, AP_small/medium/large, and per-class mask AP
  - box AP for reference
  - crown error (px) for rosettes that have a verified crown point, using the predicted-mask centroid
  - latency on this machine (ms/image, batch 1, after warm-up)

Writes results/<run>/metrics.json, results_table.png, qualitative.png, per_class.png
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from pycocotools import mask as mask_utils
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

from common import CATEGORIES, crown_estimate

VARIANTS = {"nano": "RFDETRSegNano", "small": "RFDETRSegSmall", "medium": "RFDETRSegMedium", "large": "RFDETRSegLarge"}
COLORS = {1: (255, 196, 0), 2: (90, 170, 255), 3: (60, 200, 90)}


def run_coco_eval(gt: COCO, dets: list[dict], iou_type: str) -> tuple[dict, COCOeval | None]:
    if not dets:
        return {}, None
    dt = gt.loadRes(dets)
    ev = COCOeval(gt, dt, iou_type)
    ev.evaluate()
    ev.accumulate()
    ev.summarize()
    names = ["AP", "AP50", "AP75", "AP_small", "AP_medium", "AP_large"]
    return {n: round(float(v) * 100, 1) for n, v in zip(names, ev.stats[:6])}, ev


def per_class_ap(ev: COCOeval) -> dict:
    # precision: [T, R, K, A, M] -> mean over IoU thresholds and recall, area=all, maxDets=100
    prec = ev.eval["precision"][:, :, :, 0, -1]
    out = {}
    for k, cat_id in enumerate(ev.params.catIds):
        p = prec[:, :, k]
        p = p[p > -1]
        out[next(c["name"] for c in CATEGORIES if c["id"] == cat_id)] = round(float(p.mean()) * 100, 1) if p.size else None
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=Path, required=True)
    ap.add_argument("--run", type=Path, required=True, help="training output dir (contains checkpoint_best_total.pth)")
    ap.add_argument("--variant", choices=list(VARIANTS), default="small")
    ap.add_argument("--threshold", type=float, default=0.3)
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--n-qual", type=int, default=8)
    args = ap.parse_args()

    import rfdetr

    model = getattr(rfdetr, VARIANTS[args.variant])(pretrain_weights=str(args.run / "checkpoint_best_total.pth"))
    name_to_cat = {c["name"]: c["id"] for c in CATEGORIES}
    class_names = list(model.class_names)

    test_dir = args.split / "test"
    gt = COCO(str(test_dir / "_annotations.coco.json"))
    seg_dets, box_dets, latencies, qual = [], [], [], []
    crown_err = []

    img_ids = gt.getImgIds()
    for i, img_id in enumerate(img_ids):
        info = gt.loadImgs(img_id)[0]
        img = Image.open(test_dir / info["file_name"]).convert("RGB")
        if i == 0:
            for _ in range(3):
                model.predict(img, threshold=args.threshold)  # warm-up
        t0 = time.perf_counter()
        det = model.predict(img, threshold=args.threshold)
        latencies.append((time.perf_counter() - t0) * 1000)

        masks = det.mask if det.mask is not None else np.zeros((0, info["height"], info["width"]), bool)
        pred_rosettes = []
        for m, box, cid, score in zip(masks, det.xyxy, det.class_id, det.confidence):
            cat = name_to_cat.get(class_names[int(cid)], None) if int(cid) < len(class_names) else None
            if cat is None:
                continue
            rle = mask_utils.encode(np.asfortranarray(m.astype(np.uint8)))
            rle["counts"] = rle["counts"].decode("ascii")
            x0, y0, x1, y1 = [float(v) for v in box]
            seg_dets.append({"image_id": img_id, "category_id": cat, "segmentation": rle, "score": float(score)})
            box_dets.append({"image_id": img_id, "category_id": cat, "bbox": [x0, y0, x1 - x0, y1 - y0], "score": float(score)})
            if cat == name_to_cat["rosette"] and m.any():
                pred_rosettes.append(crown_estimate(m))

        # crown error: nearest predicted crown to each verified ground-truth crown
        for a in gt.loadAnns(gt.getAnnIds(imgIds=img_id)):
            if a.get("crown") and a.get("crown_verified") and pred_rosettes:
                gx, gy = a["crown"]
                crown_err.append(min(np.hypot(px - gx, py - gy) for px, py in pred_rosettes))

        if len(qual) < args.n_qual and len(masks):
            vis = np.array(img).copy()
            for m, cid in zip(masks, det.class_id):
                cat = name_to_cat.get(class_names[int(cid)], 3) if int(cid) < len(class_names) else 3
                col = np.array(COLORS[cat], np.uint8)
                vis[m] = (0.45 * vis[m] + 0.55 * col).astype(np.uint8)
            qual.append(vis)

    seg, seg_ev = run_coco_eval(gt, seg_dets, "segm")
    box, _ = run_coco_eval(gt, box_dets, "bbox")
    metrics = {
        "split": str(args.split), "run": str(args.run), "variant": args.variant,
        "test_images": len(img_ids), "test_instances": len(gt.getAnnIds()),
        "mask": seg, "box": box,
        "mask_AP_per_class": per_class_ap(seg_ev) if seg_ev else {},
        "crown_error_px_median": round(float(np.median(crown_err)), 1) if crown_err else None,
        "crown_points_evaluated": len(crown_err),
        "latency_ms_median": round(float(np.median(latencies)), 1) if latencies else None,
        "latency_device": "see README: run on the target device (Jetson) for the deployment number",
    }
    out = args.out or Path("results") / args.run.name
    out.mkdir(parents=True, exist_ok=True)
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))

    plt.rcParams["font.family"] = ["Inter", "DejaVu Sans"]
    # results table figure
    fig, ax = plt.subplots(figsize=(10, 2.2))
    ax.axis("off")
    cols = ["Mask AP", "AP50", "AP75", "AP_S", "Box AP", "Latency (ms)"]
    vals = [seg.get("AP"), seg.get("AP50"), seg.get("AP75"), seg.get("AP_small"), box.get("AP"), metrics["latency_ms_median"]]
    tbl = ax.table(cellText=[[("—" if v is None else f"{v}") for v in vals]], colLabels=cols, loc="center", cellLoc="center")
    tbl.scale(1, 2.2)
    tbl.set_fontsize(13)
    fig.savefig(out / "results_table.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    if metrics["mask_AP_per_class"]:
        fig, ax = plt.subplots(figsize=(6, 3.2))
        names = list(metrics["mask_AP_per_class"])
        ax.barh(names, [metrics["mask_AP_per_class"][n] or 0 for n in names], color=["#E8B931", "#5AAAFF", "#3CC85A"])
        ax.set_xlabel("mask AP (COCO, IoU .50:.95)")
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        fig.savefig(out / "per_class.png", dpi=200, bbox_inches="tight")
        plt.close(fig)

    if qual:
        cols_n = 4
        rows_n = int(np.ceil(len(qual) / cols_n))
        fig, axes = plt.subplots(rows_n, cols_n, figsize=(4 * cols_n, 4 * rows_n))
        for ax, im in zip(np.atleast_1d(axes).ravel(), qual + [None] * (rows_n * cols_n - len(qual))):
            ax.axis("off")
            if im is not None:
                ax.imshow(im)
        fig.tight_layout()
        fig.savefig(out / "qualitative.png", dpi=150, bbox_inches="tight")
        plt.close(fig)


if __name__ == "__main__":
    main()
