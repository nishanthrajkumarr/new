"""Step 3: group-aware train / valid / test splits in the folder layout RF-DETR expects.

Why group-aware: photos from the same observer (or the same robot session) are near-duplicates.
A random image split leaks them into both train and test and inflates every metric.

Protocols
  in-domain   : groups (observers / sessions) are split 80/10/10; no group appears in two splits.
  cross-domain: if `own` robot captures exist, ALL of them are held out as the test set (train on web data,
                test on the robot's camera) -- this is the number that predicts field performance.

The TEST split must be human-verified before you report numbers (see README): pass the corrected file with
--test-coco and it replaces the auto-labels for those images.

Output: data/splits/<protocol>/{train,valid,test}/ with images + _annotations.coco.json
"""
from __future__ import annotations

import argparse
import random
import shutil
from collections import defaultdict
from pathlib import Path

from common import CATEGORIES, load_json, save_json


def subset(coco: dict, image_ids: set[int]) -> dict:
    imgs = [im for im in coco["images"] if im["id"] in image_ids]
    remap = {im["id"]: i + 1 for i, im in enumerate(imgs)}
    anns = []
    for a in coco["annotations"]:
        if a["image_id"] in remap:
            b = dict(a)
            b["image_id"] = remap[a["image_id"]]
            b["id"] = len(anns) + 1
            anns.append(b)
    new_imgs = []
    for im in imgs:
        j = dict(im)
        j["id"] = remap[im["id"]]
        j["file_name"] = Path(im["file_name"]).name
        new_imgs.append(j)
    return {"info": coco.get("info", {}), "licenses": [], "images": new_imgs, "annotations": anns, "categories": CATEGORIES}


def write_split(coco: dict, ids: set[int], raw: Path, dst: Path) -> int:
    dst.mkdir(parents=True, exist_ok=True)
    for im in coco["images"]:
        if im["id"] in ids:
            shutil.copy2(raw / im["file_name"], dst / Path(im["file_name"]).name)
    sub = subset(coco, ids)
    save_json(sub, dst / "_annotations.coco.json")
    return len(sub["annotations"])


def override_with_verified(coco: dict, verified: dict) -> dict:
    """Replace annotations for every image present in the verified file (matched by file name)."""
    by_name = {Path(im["file_name"]).name: im["id"] for im in coco["images"]}
    vid_to_name = {im["id"]: Path(im["file_name"]).name for im in verified["images"]}
    touched = {by_name[n] for n in vid_to_name.values() if n in by_name}
    anns = [a for a in coco["annotations"] if a["image_id"] not in touched]
    for a in verified["annotations"]:
        name = vid_to_name[a["image_id"]]
        if name in by_name:
            b = dict(a)
            b["image_id"] = by_name[name]
            b["verified"] = True
            anns.append(b)
    for i, a in enumerate(anns, 1):
        a["id"] = i
    out = dict(coco)
    out["annotations"] = anns
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=Path, default=Path("data/raw"))
    ap.add_argument("--labels", type=Path, default=Path("data/autolabel/annotations.coco.json"))
    ap.add_argument("--test-coco", type=Path, default=None, help="human-verified COCO for test images")
    ap.add_argument("--out", type=Path, default=Path("data/splits"))
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    coco = load_json(args.labels)
    if args.test_coco:
        coco = override_with_verified(coco, load_json(args.test_coco))

    groups: dict[str, list[int]] = defaultdict(list)
    for im in coco["images"]:
        groups[im.get("group", "na")].append(im["id"])

    web_groups = sorted(g for g in groups if not g.startswith("own_"))
    own_groups = sorted(g for g in groups if g.startswith("own_"))
    rng = random.Random(args.seed)
    rng.shuffle(web_groups)
    n = len(web_groups)
    g_test, g_val = web_groups[: max(1, n // 10)], web_groups[max(1, n // 10): max(2, n // 5)]
    g_train = web_groups[max(2, n // 5):]

    def ids(gs: list[str]) -> set[int]:
        return {i for g in gs for i in groups[g]}

    report = []
    for name, (tr, va, te) in {
        "in_domain": (g_train, g_val, g_test),
        **({"cross_domain": (g_train + g_test, g_val, own_groups)} if own_groups else {}),
    }.items():
        root = args.out / name
        if root.exists():
            shutil.rmtree(root)
        counts = {split: write_split(coco, ids(gs), args.raw, root / split)
                  for split, gs in (("train", tr), ("valid", va), ("test", te))}
        report.append((name, {k: len(ids(v)) for k, v in (("train", tr), ("valid", va), ("test", te))}, counts))

    for name, imgs, anns in report:
        print(f"{name:12s} images={imgs} instances={anns}")


if __name__ == "__main__":
    main()
