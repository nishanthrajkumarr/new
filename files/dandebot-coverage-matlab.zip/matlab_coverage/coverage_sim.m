function result = coverage_sim(varargin)
%COVERAGE_SIM  Complete coverage of the lower lawn of map_v2 with obstacles and people.
%
%   Plan (Fields2Cover-style): a headland ring inside a custom polygon, a ring
%   around every obstacle, boustrophedon swaths grouped into cells, cells ordered
%   nearest-first, every gap and turn joined with A* on an inflated costmap.
%   Execute: Regulated Pure Pursuit (RPP) follows the plan. When a person stands
%   on the path inside the 4 m local costmap, a local A* detour is planned and
%   DWA drives it; RPP takes over again once the path is clear. At the end a
%   coverage grid is checked, every missed patch is revisited, and the robot
%   returns to the dock.
%
%   coverage_sim                          % run with a live plot
%   coverage_sim('video', true)           % also write coverage_sim.mp4
%   coverage_sim('seed', 7, 'people', 2)  % other random people
%   coverage_sim('drawEvery', 50)         % faster: redraw less often
%   r = coverage_sim(...);                % r.P, r.poses, r.covered, ...
%
%   Map: map_v2_rot18.pgm (map_v2.pgm rotated 18 deg, see rotate_map.m).
%   Units inside: grid cells of 0.05 m; points are [x y] = [column row].
%   Requires the Image Processing Toolbox (bwdist, bwareaopen, bwlabel).
%   This is a 2D simulation with simple versions of the planners, not Nav2.

% ------------------------------------------------------------------ options
ip = inputParser;
addParameter(ip, 'map', 'map_v2_rot18.pgm');
addParameter(ip, 'seed', 20);
addParameter(ip, 'people', 3);
addParameter(ip, 'video', false);
addParameter(ip, 'videoFile', 'coverage_sim.mp4');
addParameter(ip, 'drawEvery', 20);      % sim steps (0.1 s each) between redraws
addParameter(ip, 'maxSteps', 80000);
addParameter(ip, 'plot', true);
parse(ip, varargin{:}); o = ip.Results;
if ~license('test', 'image_toolbox')
    warning('coverage_sim:ipt', 'Image Processing Toolbox not found: bwdist / bwareaopen / bwlabel are needed.');
end
rng(o.seed);

% ------------------------------------------------------------------ constants
RES = 0.05;  M = @(m) m / RES;                 % metres -> cells
R_ROBOT = M(0.30); R_INF = M(0.55); KDEC = 6.0 * RES;
SW = M(0.55); SP = M(0.45); RC = SW / 2;       % cutter diameter, swath spacing, cutter radius
SAFE = M(0.35);                                % planning clearance for the robot centre
VMAX = M(0.45); WMAX = 1.6; DT = 0.1; ACC = M(0.8); WACC = 3.0;
SENSOR = M(2.5); LOCAL = round(M(4.0));
TRANSIT = 1; HEADLAND = 2; CONTOUR = 3; TURN = 4; SWATH = 5; REVISIT = 6; DOCKT = 7;

% ------------------------------------------------------------------ map + costmap
if ~isfile(o.map) && isfile('map_v2.pgm')
    fprintf('%s not found: rotating map_v2.pgm by 18 deg (coordinates may shift by a pixel)\n', o.map);
    rotate_map('map_v2.pgm', o.map, 18);
end
raw = imread(o.map); if size(raw, 3) > 1, raw = raw(:, :, 1); end
raw = double(raw); [H, W] = size(raw);
occ = bwareaopen(raw < 50, 12, 8);                         % drop SLAM speckle (< 12 cells)
unkBig = bwareaopen(raw == 205, 200, 4);                   % small unknown islands count as free
lethal = occ | unkBig;
dist = double(bwdist(lethal));                             % cells to the nearest obstacle
gcost = zeros(H, W);
m_ = dist <= R_INF; gcost(m_) = 252 * exp(-KDEC * (dist(m_) - R_ROBOT));
gcost(dist <= R_ROBOT) = 253; gcost(dist <= 0) = 254;      % inscribed / lethal

% ------------------------------------------------------------------ custom polygon (whole lower lawn)
POLY = [72 404; 250 404; 262 398; 420 398; 470 404; 640 404; 688 428; 690 648; 650 668; 650 736; ...
        616 796; 548 796; 528 752; 436 744; 404 770; 300 782; 170 778; 130 712; 72 694] + 1;
[XX, YY] = meshgrid(1:W, 1:H);
inpoly = inpolygon(XX, YY, POLY(:, 1), POLY(:, 2));
dpoly = double(bwdist(~inpoly));                                   % cells to the polygon edge (inside)
DOCK0 = [86 415];
reach0 = dist >= SAFE;
Lr = bwlabel(reach0, 4);
[~, ix0] = bwdist(Lr > 0); lab0 = Lr(ix0(DOCK0(2), DOCK0(1)));
reach = Lr == lab0;                                        % free space connected to the dock
[dReach, nearIdx] = bwdist(reach); dReach = double(dReach);
[dy_, dx_] = ind2sub([H W], nearIdx(DOCK0(2), DOCK0(1))); DOCK = [dx_ dy_];
mowable = inpoly & ~lethal & dReach <= RC - 1;
fprintf('polygon %.1f m^2, mowable %.1f m^2\n', nnz(inpoly) * RES^2, nnz(mowable) * RES^2);

% ------------------------------------------------------------------ plan: headland, obstacle rings, swaths
% 1) headland ring: polygon edge inset by half the cutter
lines = contour_lines(dpoly, RC);
[~, li] = max(cellfun(@(z9) size(z9, 1), lines));
ring = resample_line(lines{li}, 1.0);
[~, k0] = min(hypot(ring(:, 1) - DOCK(1), ring(:, 2) - DOCK(2)));
ring = [ring(k0:end, :); ring(1:k0 - 1, :)];
headland = runs_of(ring, okpt(ring, 200), 8);

% 2) rings around obstacles inside the polygon
items = struct('kind', {}, 'pts', {}, 'closed', {}, 'rows', {});
lines = contour_lines(dist, SAFE + 0.5);
for q = 1:numel(lines)
    ln = resample_line(lines{q}, 1.0);
    cq = clampi(ln);
    ok = okpt(ln, 253) & dpoly(sub2ind([H W], cq(:, 2), cq(:, 1))) >= RC + 2;
    closed = hypot(ln(1, 1) - ln(end, 1), ln(1, 2) - ln(end, 2)) < 2 && all(ok);
    rr = runs_of(ln, ok, 20);
    for r = 1:numel(rr)
        items(end + 1) = struct('kind', 'contour', 'pts', rr{r}, 'closed', closed, 'rows', []); %#ok<AGROW>
    end
end
nRings = numel(items);

% 3) swaths, grouped into boustrophedon cells
rowsY = (min(POLY(:, 2)) + RC + SP):SP:max(POLY(:, 2));
cells = {}; prevRows = zeros(0, 3);
for yrow = rowsY
    yi = round(yrow);
    ok = dpoly(yi, :) >= RC + 3 & gcost(yi, :) < 200 & reach(yi, :);
    rr = runs_of([(1:W)' repmat(yrow, W, 1)], ok(:), round(M(1.0)));
    ab = zeros(numel(rr), 2);
    for r = 1:numel(rr), ab(r, :) = [rr{r}(1, 1) rr{r}(end, 1)]; end
    curRow = zeros(0, 3);
    for r = 1:size(ab, 1)
        a = ab(r, 1); b = ab(r, 2);
        ov = find(prevRows(:, 1) <= b & prevRows(:, 2) >= a);
        if numel(ov) == 1
            pa = prevRows(ov, 1); pb = prevRows(ov, 2); cid = prevRows(ov, 3);
            if sum(ab(:, 1) <= pb & ab(:, 2) >= pa) == 1
                cells{cid}(end + 1, :) = [yrow a b]; curRow(end + 1, :) = [a b cid]; %#ok<AGROW>
                continue
            end
        end
        cells{end + 1} = [yrow a b]; curRow(end + 1, :) = [a b numel(cells)]; %#ok<AGROW>
    end
    prevRows = curRow;
end
for ci = 1:numel(cells)
    items(end + 1) = struct('kind', 'cell', 'pts', [], 'closed', false, 'rows', cells{ci}); %#ok<AGROW>
end
fprintf('headland runs %d, obstacle rings %d, swath cells %d, swath rows %d\n', numel(headland), nRings, numel(cells), numel(rowsY));

% ------------------------------------------------------------------ order the items and stitch the plan
path = zeros(60000, 2); tag = zeros(60000, 1); np = 0;
addpts(DOCK, TRANSIT);
for r = 1:numel(headland), go(headland{r}(1, :), TRANSIT); addpts(headland{r}, HEADLAND); end
best = greedy_order(0);
for tries = 1:100                                   % nearest-first with random tie-breaks; keep the shortest
    candB = greedy_order(0.8);
    if candB.tot < best.tot, best = candB; end
end
fprintf('transit estimate %.1f m\n', best.tot * RES);
for q = 1:size(best.seq, 1)
    itm = items(best.seq(q, 1)); how = best.seq(q, 2:3);
    if strcmp(itm.kind, 'contour')
        ipts = itm.pts;
        if how(1) == 1, kq = how(2); ipts = [ipts(kq:end, :); ipts(1:kq - 1, :); ipts(kq, :)];
        elseif how(1) == 3, ipts = flipud(ipts); end
        go(ipts(1, :), TRANSIT); addpts(ipts, CONTOUR);
    else
        iR = itm.rows; if how(1) == 12, iR = flipud(iR); end
        id = how(2);
        for r = 1:size(iR, 1)
            sseg = [(iR(r, 2):iR(r, 3))' repmat(iR(r, 1), iR(r, 3) - iR(r, 2) + 1, 1)];
            if id < 0, sseg = flipud(sseg); end
            go(sseg(1, :), TURN); addpts(sseg, SWATH); id = -id;
        end
    end
end
P = path(1:np, :); TAG = tag(1:np); MAIN_N = np;
seglen = [0; cumsum(hypot(diff(P(:, 1)), diff(P(:, 2))))];
fprintf('plan length %.1f m\n', seglen(end) * RES);

% ------------------------------------------------------------------ people (dynamic obstacles)
people = struct('p', {}, 'stand', {}, 'j', {}, 'out', {}, 't0', {}, 'r', {}, 'state', {}, 'ts', {}, 'v', {}, 't1', {});
SPAWN_AT = sort(0.10 + 0.75 * rand(1, o.people));
spawned = false(1, o.people);

% ------------------------------------------------------------------ figure
r0 = 386; r1 = 813; c0 = 41; c1 = 713;                     % display crop (rows, columns)
hA = struct(); vw = [];
if o.plot, setup_figure(); end
if o.video && ~o.plot, o.video = false; warning('coverage_sim:video', 'video needs plot = true'); end
if o.video
    try
        vw = VideoWriter(o.videoFile, 'MPEG-4');
    catch
        [~, base_] = fileparts(o.videoFile); o.videoFile = [base_ '.avi'];
        vw = VideoWriter(o.videoFile, 'Motion JPEG AVI');           % MPEG-4 not available on this system
    end
    vw.FrameRate = 24; open(vw);
end

% ------------------------------------------------------------------ simulation
s = [P(1, :) 0]; v = 0; w = 0;
mode = 1; idx = 1; t = 0; modeSince = 0;        % mode 1 = RPP, 2 = DWA
D = []; Dt = -9; phase = 1; rounds = 0;         % phase 1 = plan, 2 = revisit, 3 = dock
cut = false(H, W); cutMain = [];
poses = zeros(o.maxSteps, 3); stepMode = zeros(o.maxSteps, 1); stepPhase = zeros(o.maxSteps, 1);
bestIdx = 1; bestT = 0; nskip = 0; goals = zeros(0, 2); lastMiss = inf; lastDwaT = -inf;
reason = 'following the coverage plan'; look = 1; rolls = struct('xy', {}, 'sc', {});
newt = TRANSIT;
if o.plot, show_plan(); end
for step = 1:o.maxSteps
    if phase == 1
        for kp = 1:o.people
            if ~spawned(kp) && seglen(idx) >= SPAWN_AT(kp) * seglen(MAIN_N), spawn(idx, t, s(1:2)); spawned(kp) = true; end
        end
    end
    live = find(arrayfun(@(q9) q9.t0 <= t && t < q9.t1, people));
    for kl = live(:)', person_step(kl); end
    seen = people(live);
    if ~isempty(seen), seen = seen(arrayfun(@(q9) hypot(q9.p(1) - s(1), q9.p(2) - s(2)) < SENSOR + q9.r, seen)); end
    [idx, xte] = nearest_ahead(s(1:2), idx);
    if idx > bestIdx, bestIdx = idx; bestT = t;
    elseif t - bestT > 12 && mode == 1             % watchdog (recovery): skip a short piece of path
        idx = min(size(P, 1), idx + 15); bestIdx = idx; bestT = t; nskip = nskip + 1;
    end
    ahead = P(idx:min(size(P, 1), idx + round(M(2.0)) - 1), :);
    blocked = false;
    for ks = 1:numel(seen)
        sp = seen(ks);
        if any(hypot(ahead(:, 1) - sp.p(1), ahead(:, 2) - sp.p(2)) < sp.r + R_ROBOT + M(0.15)) || ...
                hypot(sp.p(1) - s(1), sp.p(2) - s(2)) < sp.r + R_ROBOT + M(0.35)
            blocked = true;
        end
    end
    if mode == 1 && blocked
        mode = 2; modeSince = t; D = []; Dt = -9; reason = 'a person is standing on the path';
    elseif mode == 2 && ~blocked && xte < M(0.12) && t - modeSince > 1.0
        mode = 1; modeSince = t; reason = 'path clear and back on it';
    end
    rolls = struct('xy', {}, 'sc', {});
    if mode == 1
        [vc, wc, look] = rpp(s, idx);
    else
        lastDwaT = t;
        if isempty(D) || t - Dt > 1.0
            Dn = local_detour(s, idx, seen);
            if ~isempty(Dn), D = Dn; Dt = t; end
        end
        if isempty(D), vc = 0; wc = 0; else, [vc, wc, rolls] = dwa(s, v, w, D, seen); end
    end
    v = min(max(vc, v - ACC * DT), v + ACC * DT); w = min(max(wc, w - WACC * DT), w + WACC * DT);
    s(3) = s(3) + w * DT; s(1) = s(1) + v * cos(s(3)) * DT; s(2) = s(2) + v * sin(s(3)) * DT;
    stamp(s(1:2));
    poses(step, :) = s; stepMode(step) = mode; stepPhase(step) = phase;
    if o.plot
        slow = mode == 2 || t - lastDwaT < 4;
        if mod(step, o.drawEvery) == 0 || (slow && mod(step, 3) == 0), draw_frame(step); end
    end
    t = t + DT;
    % ---- end of the current path: next revisit goal, a new revisit round, or the dock
    tol = 3; if phase == 2, tol = 1.2; end
    N = size(P, 1);
    if idx >= N - 2 && hypot(P(N, 1) - s(1), P(N, 2) - s(2)) < tol
        if phase == 3, break; end
        newp = [];
        while phase == 2 && ~isempty(goals) && size(newp, 1) < 2
            gq = goals(1, :); goals(1, :) = [];
            aq = astar_grid(gcost, s(1:2), gq);
            if size(aq, 1) >= 2, newp = aq; newt = REVISIT; end
        end
        if isempty(newp)
            miss = nnz(mowable & ~cut);
            if phase == 1, cutMain = cut; end
            fprintf('end of %s, round %d, t = %.0f s: missed %d cells (%.2f%%)\n', ...
                    ternary(phase == 1, 'plan', 'revisit'), rounds, t, miss, 100 * miss / nnz(mowable));
            if miss > 0 && rounds < 3 && miss < 0.8 * lastMiss
                goals = plan_revisit(s(1:2)); rounds = rounds + 1; phase = 2; lastMiss = miss;
                reason = sprintf('coverage grid check: %d revisit points', size(goals, 1));
                while ~isempty(goals) && size(newp, 1) < 2
                    gq = goals(1, :); goals(1, :) = [];
                    aq = astar_grid(gcost, s(1:2), gq);
                    if size(aq, 1) >= 2, newp = aq; newt = REVISIT; end
                end
            end
            if isempty(newp)
                newp = astar_grid(gcost, s(1:2), DOCK); newt = DOCKT; phase = 3; reason = 'coverage complete: back to the dock';
            end
        end
        P = [P; newp]; TAG = [TAG; repmat(newt, size(newp, 1), 1)]; %#ok<AGROW>
        seglen = [0; cumsum(hypot(diff(P(:, 1)), diff(P(:, 2))))];
    end
end
nsteps = step;
covered = nnz(cut & mowable) / nnz(mowable);
fprintf('sim time %.1f min, covered %.2f%% of mowable area, revisit rounds %d, DWA share %.3f, watchdog skips %d\n', ...
        t / 60, 100 * covered, rounds, mean(stepMode(1:nsteps) == 2), nskip);
if o.plot, draw_frame(nsteps); end
if o.video, close(vw); fprintf('video written to %s\n', o.videoFile); end
result = struct('P', P, 'TAG', TAG, 'MAIN_N', MAIN_N, 'poses', poses(1:nsteps, :), 'mode', stepMode(1:nsteps), ...
                'phase', stepPhase(1:nsteps), 'cut', cut, 'cutMain', cutMain, 'mowable', mowable, 'covered', covered, ...
                'time_s', t, 'plan_m', seglen(MAIN_N) * RES, 'polygon', POLY, 'dock', DOCK);

% =================================================================== nested helpers (share the workspace)
    function c = clampi(pts)
        c = round(pts); c(:, 1) = min(max(c(:, 1), 1), W); c(:, 2) = min(max(c(:, 2), 1), H);
    end
    function ok = okpt(pts, lim)
        c = clampi(pts); li_ = sub2ind([H W], c(:, 2), c(:, 1));
        ok = gcost(li_) < lim & reach(li_);
    end
    function addpts(pts, tg)
        for i_ = 1:size(pts, 1)
            if np > 0 && hypot(pts(i_, 1) - path(np, 1), pts(i_, 2) - path(np, 2)) < 0.5, continue; end
            np = np + 1; path(np, :) = pts(i_, :); tag(np) = tg;
        end
    end
    function go(p, tg)
        if np > 0
            a_ = astar_grid(gcost, path(np, :), p);
            if ~isempty(a_), addpts(a_, tg); end
        end
    end
    function E = entries_at(it, cur)
        % each row: [entry_x entry_y how1 how2 exit_x exit_y]
        if strcmp(it.kind, 'contour')
            pts = it.pts;
            if it.closed
                [~, k_] = min(hypot(pts(:, 1) - cur(1), pts(:, 2) - cur(2)));
                E = [pts(k_, :) 1 k_ pts(k_, :)];
            else
                E = [pts(1, :) 2 0 pts(end, :); pts(end, :) 3 0 pts(1, :)];
            end
        else
            R = it.rows; nr = size(R, 1); E = zeros(4, 6); q_ = 0;
            for f = [11 12]
                for d = [1 -1]
                    if f == 11, fr = R(1, :); lr = R(end, :); else, fr = R(end, :); lr = R(1, :); end
                    if d > 0, e = [fr(2) fr(1)]; else, e = [fr(3) fr(1)]; end
                    if mod(nr, 2) == 1, dl = d; else, dl = -d; end
                    if dl > 0, ex = [lr(3) lr(1)]; else, ex = [lr(2) lr(1)]; end
                    q_ = q_ + 1; E(q_, :) = [e f d ex];
                end
            end
        end
    end
    function out = greedy_order(noise)
        cur = path(np, :); left = 1:numel(items); seq = zeros(0, 3); tot = 0;
        while ~isempty(left)
            opts = zeros(0, 6);
            for i_ = left
                E = entries_at(items(i_), cur);
                opts = [opts; hypot(E(:, 1) - cur(1), E(:, 2) - cur(2)) repmat(i_, size(E, 1), 1) E(:, 3:6)]; %#ok<AGROW>
            end
            opts = sortrows(opts, 1);
            if noise > 0, pick = 1 + min(size(opts, 1) - 1, floor(-noise * log(rand))); else, pick = 1; end
            op = opts(pick, :);
            tot = tot + op(1); seq(end + 1, :) = op(2:4); left(left == op(2)) = []; cur = op(5:6); %#ok<AGROW>
        end
        out = struct('tot', tot, 'seq', seq);
    end
    function d = dyn_dist(pts, seen_)
        d = inf(size(pts, 1), 1);
        for i_ = 1:numel(seen_)
            d = min(d, hypot(pts(:, 1) - seen_(i_).p(1), pts(:, 2) - seen_(i_).p(2)) - seen_(i_).r);
        end
    end
    function cs = cost_at(pts, seen_)
        c = clampi(pts); cs = gcost(sub2ind([H W], c(:, 2), c(:, 1)));
        if ~isempty(seen_), cs = max(cs, inflate_dyn(dyn_dist(pts, seen_))); end
    end
    function c = inflate_dyn(d)
        c = zeros(size(d));
        m2 = d <= R_ROBOT + M(0.12); c(m2) = 200 * exp(-12 * RES * (d(m2) - R_ROBOT));
        c(d <= R_ROBOT) = 253; c(d <= 0) = 254;
    end
    function [k, xte_] = nearest_ahead(p, i0)
        j_ = i0:min(size(P, 1), i0 + 49);
        [xte_, kk] = min(hypot(P(j_, 1) - p(1), P(j_, 2) - p(2))); k = i0 + kk - 1;
    end
    function [vc_, wc_, j_] = rpp(st, i0)
        N_ = size(P, 1); tg = TAG(i0); nx = TAG(i0:min(N_, i0 + 15));
        if any(tg == [SWATH TRANSIT DOCKT]) && all(nx == tg), L = M(0.6);
        elseif tg == REVISIT, L = M(0.2); else, L = M(0.3); end
        j_ = i0;
        while j_ < N_ && hypot(P(j_, 1) - st(1), P(j_, 2) - st(2)) < L, j_ = j_ + 1; end
        dx = P(j_, 1) - st(1); dy = P(j_, 2) - st(2); cc = cos(-st(3)); sn = sin(-st(3));
        lx = cc * dx - sn * dy; ly = sn * dx + cc * dy; ang = atan2(ly, lx);
        if abs(ang) > 0.7, vc_ = 0; wc_ = sign(ang) * min(WMAX, 1.4); return; end   % rotate to heading
        Ld = max(hypot(lx, ly), 1e-3); kap = 2 * ly / Ld^2;
        vv = VMAX; if tg == REVISIT, vv = M(0.4); end
        if abs(kap) > 1e-6 && 1 / abs(kap) < M(0.9), vv = vv * (1 / abs(kap)) / M(0.9); end   % curvature regulation
        cst = cost_at(st(1:2), []); if cst > 60, vv = vv * max(0.4, 1 - (cst - 60) / 250); end % proximity regulation
        vv = max(vv, M(0.08)); vc_ = vv; wc_ = min(max(vv * kap, -WMAX), WMAX);
    end
    function p = local_detour(st, i0, seen_)
        % re-plan around what the local costmap sees: A* to the first free path point past the blockage
        N_ = size(P, 1); tg_ = i0;
        while tg_ < N_ && (seglen(tg_) - seglen(i0) < M(1.0) || cost_at(P(tg_, :), seen_) >= 40), tg_ = tg_ + 1; end
        tg_ = min(N_, tg_ + round(M(0.3)));
        a_ = st(1:2); b_ = P(tg_, :);
        lo = max(floor(min(a_, b_) - M(1.5)), [1 1]); hi = min(ceil(max(a_, b_) + M(1.5)), [W H]);
        [gx, gy] = meshgrid(lo(1):hi(1), lo(2):hi(2)); gp = [gx(:) gy(:)];
        cg = cost_at(gp, seen_); cg(dyn_dist(gp, seen_) <= R_ROBOT + 2) = 253;   % keep 0.1 m extra from people
        p = astar_grid(reshape(cg, size(gx)), a_ - lo + 1, b_ - lo + 1);
        if ~isempty(p)
            p = p + lo - 1;
            if size(p, 1) > 2
                for it_ = 1:2, p(2:end - 1, :) = 0.25 * p(1:end - 2, :) + 0.5 * p(2:end - 1, :) + 0.25 * p(3:end, :); end
            end
        end
    end
    function [vc_, wc_, rl] = dwa(st, v0, w0, Dp, seen_)
        % sample (v, w), roll out 2.2 s, score goal / heading / path / obstacle / speed
        rl = struct('xy', {}, 'sc', {});
        [~, k] = min(hypot(Dp(:, 1) - st(1), Dp(:, 2) - st(2)));
        j_ = min(size(Dp, 1), k + round(M(0.6)));
        tgv = Dp(min(size(Dp, 1), k + 5), :) - Dp(k, :);
        herr = mod(atan2(tgv(2), tgv(1)) - st(3) + pi, 2 * pi) - pi;
        if abs(herr) > 0.9, vc_ = 0; wc_ = sign(herr) * 1.2; return; end           % rotate to the detour heading first
        vs = unique([linspace(max(M(0.08), v0 - ACC), min(VMAX, v0 + ACC), 6) 0]);
        ws = linspace(max(-WMAX, w0 - WACC * 0.8), min(WMAX, w0 + WACC * 0.8), 17);
        bestS = inf; vc_ = 0; wc_ = 0; kk = (1:22)';
        for vv = vs
            for ww = ws
                th = st(3) + ww * DT * kk;
                xy = [st(1) + cumsum(vv * cos(th) * DT), st(2) + cumsum(vv * sin(th) * DT)];
                cs = cost_at(xy, seen_);
                if any(cs >= 253), rl(end + 1) = struct('xy', xy, 'sc', inf); continue; end %#ok<AGROW>
                e = [xy(end, :) th(end)]; dd = Dp(j_, :) - e(1:2);
                head = abs(mod(atan2(dd(2), dd(1)) - e(3) + pi, 2 * pi) - pi);
                pdist = min(hypot(Dp(:, 1) - e(1), Dp(:, 2) - e(2)));
                sc = hypot(dd(1), dd(2)) + head + 1.5 * pdist + 0.02 * mean(cs) - 0.5 * vv;
                rl(end + 1) = struct('xy', xy, 'sc', sc); %#ok<AGROW>
                if sc < bestS, bestS = sc; vc_ = vv; wc_ = ww; end
            end
        end
    end
    function stamp(c)
        x = round(c(1)); y = round(c(2)); R_ = ceil(RC) + 1;
        ys = max(y - R_, 1):min(y + R_, H); xs = max(x - R_, 1):min(x + R_, W);
        [gx, gy] = meshgrid(xs, ys);
        cut(ys, xs) = cut(ys, xs) | ((gx - c(1)).^2 + (gy - c(2)).^2 <= RC^2);
    end
    function C = plan_revisit(start)
        % greedy cover of every mowable cell the coverage grid says was missed
        [ys, xs] = find(mowable & ~cut); pts = [xs ys]; alive = true(size(pts, 1), 1);
        cur = start; C = zeros(0, 2); Rr = floor(RC - 1.5);
        while any(alive)
            ia = find(alive); [~, mm] = min(hypot(pts(ia, 1) - cur(1), pts(ia, 2) - cur(2)));
            k = ia(mm); tgt = pts(k, :);
            yy = max(tgt(2) - Rr, 1):min(tgt(2) + Rr, H); xx = max(tgt(1) - Rr, 1):min(tgt(1) + Rr, W);
            [cx, cy] = meshgrid(xx, yy);
            msk = reach(yy, xx) & ((cx - tgt(1)).^2 + (cy - tgt(2)).^2 <= Rr^2);
            if any(msk(:))
                cand = [cx(msk) cy(msk)]; score = zeros(size(cand, 1), 1);
                for q_ = 1:size(cand, 1)
                    score(q_) = nnz(alive & hypot(pts(:, 1) - cand(q_, 1), pts(:, 2) - cand(q_, 2)) <= RC - 1.5);
                end
                [~, bq] = max(score); c = cand(bq, :);
            else
                [ny, nx] = ind2sub([H W], nearIdx(tgt(2), tgt(1))); c = [nx ny];
            end
            C(end + 1, :) = c; %#ok<AGROW>
            alive = alive & hypot(pts(:, 1) - c(1), pts(:, 2) - c(2)) > RC - 1.5; alive(k) = false; cur = c;
        end
        fprintf('revisit points: %d\n', size(C, 1));
    end
    function spawn(i0, tnow, robot)
        % a person walks in from the side and stands on a swath about 3 m ahead of the robot
        for tries_ = 1:80
            j_ = min(MAIN_N, i0 + floor(M(2.6 + 0.6 * rand)));
            jr = j_:min(MAIN_N, j_ + round(M(1.5)) - 1);
            if TAG(j_) ~= SWATH || any(TAG(jr) ~= SWATH) || hypot(P(j_, 1) - robot(1), P(j_, 2) - robot(2)) < M(2.0)
                i0 = i0 + 10; continue
            end
            tang = P(min(j_ + 3, size(P, 1)), :) - P(max(j_ - 3, 1), :); tang = tang / (norm(tang) + 1e-9);
            nrm = [-tang(2) tang(1)]; stand = P(j_, :);
            if dist(round(stand(2)), round(stand(1))) < M(0.2) + 2 * R_ROBOT + M(0.25), i0 = i0 + 10; continue; end
            for side = (2 * (rand > 0.5) - 1) * [1 -1]
                st0 = stand + side * nrm * M(1.4);
                lnp = clampi([linspace(st0(1), stand(1), 30)' linspace(st0(2), stand(2), 30)']);
                if all(gcost(sub2ind([H W], lnp(:, 2), lnp(:, 1))) < 200)
                    vdir = (stand - st0) / (norm(stand - st0) + 1e-9) * M(0.35);
                    people(end + 1) = struct('p', st0, 'stand', stand, 'j', j_, 'out', -side * nrm, 't0', tnow, ...
                                             'r', M(0.2), 'state', 1, 'ts', tnow, 'v', vdir, 't1', inf);
                    return
                end
            end
            i0 = i0 + 10;
        end
    end
    function person_step(k)
        pp = people(k); robot = s(1:2);
        switch pp.state
            case 1   % walk in, never closer than the robot's footprint
                nxt = pp.p + pp.v * DT;
                if hypot(nxt(1) - robot(1), nxt(2) - robot(2)) > pp.r + R_ROBOT + M(0.25), pp.p = nxt; end
                if hypot(pp.stand(1) - pp.p(1), pp.stand(2) - pp.p(2)) < M(0.05)
                    pp.p = pp.stand; pp.state = 2; pp.ts = t; pp.v = [0 0];
                end
            case 2   % stand until the robot has gone past
                if idx > pp.j + round(M(1.2)) && t - pp.ts > 4.0 && hypot(robot(1) - pp.p(1), robot(2) - pp.p(2)) > M(1.2)
                    pp.state = 3; pp.ts = t; pp.v = pp.out * M(0.35);
                end
            otherwise % walk off
                nxt = pp.p + pp.v * DT; cn = clampi(nxt);
                if gcost(cn(2), cn(1)) < 253, pp.p = nxt; end
                if t - pp.ts > 6, pp.t1 = t; end
        end
        people(k) = pp;
    end

% =================================================================== drawing (one simple plot)
    function setup_figure()
        hA.fig = figure('Color', 'w', 'Name', 'Coverage on map_v2');
        hA.ax = axes(hA.fig);
        imagesc(hA.ax, raw); colormap(hA.ax, gray); axis(hA.ax, 'image'); hold(hA.ax, 'on');
        xlim(hA.ax, [c0 c1]); ylim(hA.ax, [r0 r1]);
        green = cat(3, zeros(H, W), 0.6 * ones(H, W), zeros(H, W));
        hA.cut = image(hA.ax, green, 'AlphaData', zeros(H, W));          % mowed area
        plot(hA.ax, POLY([1:end 1], 1), POLY([1:end 1], 2), 'g--', 'LineWidth', 1.5);
        plot(hA.ax, DOCK(1), DOCK(2), 'ks', 'MarkerSize', 10, 'MarkerFaceColor', 'w');
        hA.plan = plot(hA.ax, nan, nan, 'b-', 'LineWidth', 0.5);
        hA.trail = plot(hA.ax, nan, nan, 'b-', 'LineWidth', 1);              % RPP
        hA.dwa = plot(hA.ax, nan, nan, 'm-', 'LineWidth', 2);                % DWA around a person
        hA.rev = plot(hA.ax, nan, nan, '-', 'Color', [1 0.5 0], 'LineWidth', 1.5);   % revisit
        hA.rob = plot(hA.ax, nan, nan, 'ko', 'MarkerSize', 7, 'MarkerFaceColor', 'k');
        hA.ppl = plot(hA.ax, nan, nan, 'ro', 'MarkerSize', 9, 'MarkerFaceColor', 'r');
        legend(hA.ax, [hA.trail hA.dwa hA.rev hA.ppl], {'RPP', 'DWA', 'revisit', 'person'}, 'Location', 'southoutside', 'Orientation', 'horizontal');
    end
    function show_plan()
        set(hA.plan, 'XData', P(1:MAIN_N, 1), 'YData', P(1:MAIN_N, 2));
        title(hA.ax, sprintf('Plan: %d obstacle rings, %d swath cells, %.0f m', nRings, numel(cells), seglen(MAIN_N) * RES));
        drawnow;
        if o.video, for f_ = 1:48, writeVideo(vw, getframe(hA.fig)); end, else, pause(2); end
        set(hA.plan, 'XData', nan, 'YData', nan);
    end
    function draw_frame(n)
        if ~isgraphics(hA.ax), return; end
        set(hA.cut, 'AlphaData', 0.35 * (cut & ~lethal));
        tr = poses(1:n, 1:2); md = stepMode(1:n); ph = stepPhase(1:n);
        a_ = tr; a_(md ~= 1 | ph ~= 1, :) = nan;
        b_ = tr; b_(md ~= 2, :) = nan;
        c_ = tr; c_(ph == 1 | md == 2, :) = nan;
        set(hA.trail, 'XData', a_(:, 1), 'YData', a_(:, 2));
        set(hA.dwa, 'XData', b_(:, 1), 'YData', b_(:, 2));
        set(hA.rev, 'XData', c_(:, 1), 'YData', c_(:, 2));
        set(hA.rob, 'XData', s(1), 'YData', s(2));
        liveP = people(arrayfun(@(q9) q9.t0 <= t && t < q9.t1, people));
        if isempty(liveP), set(hA.ppl, 'XData', nan, 'YData', nan);
        else, pxy = reshape([liveP.p], 2, []).'; set(hA.ppl, 'XData', pxy(:, 1), 'YData', pxy(:, 2)); end
        ctrl = {'RPP', 'DWA'}; phases = {'coverage plan', 'revisit', 'to dock'};
        title(hA.ax, sprintf('t = %.1f min | %s | %s | mowed %.1f%%', t / 60, ctrl{mode}, phases{phase}, ...
            100 * nnz(cut & mowable) / nnz(mowable)));
        drawnow limitrate;
        if o.video, writeVideo(vw, getframe(hA.fig)); end
    end
end

% =================================================================== local helpers
function lines = contour_lines(Z, level)
% all contour polylines of Z at one level, as {Nx2 [x y]}
C = contourc(Z, [level level]); lines = {}; k = 1;
while k < size(C, 2)
    n = C(2, k); lines{end + 1} = C(:, k + 1:k + n)'; k = k + n + 1; %#ok<AGROW>
end
end

function out = resample_line(line, step)
d = [0; cumsum(hypot(diff(line(:, 1)), diff(line(:, 2))))];
[d, ia] = unique(d); line = line(ia, :);
if numel(d) < 2 || d(end) < step, out = line; return; end
u = (0:step:d(end))'; u = u(u < d(end));
out = [interp1(d, line(:, 1), u) interp1(d, line(:, 2), u)];
end

function runs = runs_of(pts, ok, minlen)
% consecutive stretches of pts where ok is true, at least minlen points long
runs = {}; ok = ok(:)'; d = diff([0 ok 0]);
st = find(d == 1); en = find(d == -1) - 1;
for i = 1:numel(st)
    if en(i) - st(i) + 1 >= minlen, runs{end + 1} = pts(st(i):en(i), :); end %#ok<AGROW>
end
end

function p = astar_grid(cg, s, g)
% 8-connected A* on a cost grid (cells >= 253 are blocked except right next to the start).
% s, g: [x y] in grid coordinates. Returns an Nx2 smoothed path, or [] if unreachable.
[hh, ww] = size(cg);
s = min(max(round(s), [1 1]), [ww hh]); g = min(max(round(g), [1 1]), [ww hh]);
gs = inf(hh, ww); closed = false(hh, ww); prev = zeros(hh, ww, 'uint32');
si = (s(1) - 1) * hh + s(2); gi = (g(1) - 1) * hh + g(2);
gs(si) = 0;
hk = zeros(4096, 1); hv = zeros(4096, 1); n = 1; hk(1) = hypot(s(1) - g(1), s(2) - g(2)); hv(1) = si;
dxs = [-1 1 0 0 -1 -1 1 1]; dys = [0 0 -1 1 -1 1 -1 1]; wts = [1 1 1 1 1.414 1.414 1.414 1.414];
found = si == gi;
while n > 0 && ~found
    u = hv(1); hk(1) = hk(n); hv(1) = hv(n); n = n - 1; i = 1;          % pop the smallest key
    while true
        l = 2 * i; if l > n, break; end
        m = l; if l + 1 <= n && hk(l + 1) < hk(l), m = l + 1; end
        if hk(i) <= hk(m), break; end
        tk = hk(i); hk(i) = hk(m); hk(m) = tk; tv = hv(i); hv(i) = hv(m); hv(m) = tv; i = m;
    end
    if closed(u), continue; end
    closed(u) = true;
    if u == gi, found = true; break; end
    ux = floor((u - 1) / hh) + 1; uy = u - (ux - 1) * hh;
    for q = 1:8
        vx = ux + dxs(q); vy = uy + dys(q);
        if vx < 1 || vy < 1 || vx > ww || vy > hh, continue; end
        c = cg(vy, vx);
        if c >= 253 && hypot(vx - s(1), vy - s(2)) > 3, continue; end
        vi = (vx - 1) * hh + vy;
        nd = gs(u) + wts(q) * (1 + c / 50);
        if nd < gs(vi)
            gs(vi) = nd; prev(vi) = u;
            n = n + 1; if n > numel(hk), hk(2 * end) = 0; hv(2 * end) = 0; end     % push
            i = n; hk(i) = nd + hypot(vx - g(1), vy - g(2)); hv(i) = vi;
            while i > 1
                pi_ = floor(i / 2); if hk(pi_) <= hk(i), break; end
                tk = hk(pi_); hk(pi_) = hk(i); hk(i) = tk; tv = hv(pi_); hv(pi_) = hv(i); hv(i) = tv; i = pi_;
            end
        end
    end
end
if ~found, p = []; return; end
idxs = gi;
while idxs(end) ~= si, idxs(end + 1) = double(prev(idxs(end))); end %#ok<AGROW>
idxs = flipud(idxs(:));
px = floor((idxs - 1) / hh) + 1; py = idxs - (px - 1) * hh;
p = [px py];
if size(p, 1) > 2
    for it = 1:4, p(2:end - 1, :) = 0.25 * p(1:end - 2, :) + 0.5 * p(2:end - 1, :) + 0.25 * p(3:end, :); end
end
end

function out = ternary(c, a, b)
if c, out = a; else, out = b; end
end
