function rotate_map(inFile, outFile, angleDeg)
%ROTATE_MAP  Rotate a ROS occupancy map (PGM) so the lawn edges line up with the image axes.
%   rotate_map('map_v2.pgm', 'map_v2_rot18.pgm', 18)
%   Positive angle = counter-clockwise. New pixels are unknown (205). The result is
%   cropped to the known area plus a 10-pixel border. Nearest-neighbour keeps the
%   map trinary (0 occupied, 205 unknown, 254 free).
if nargin < 3, angleDeg = 18; end
raw = imread(inFile); if size(raw, 3) > 1, raw = raw(:, :, 1); end
R = imrotate(raw, angleDeg, 'nearest', 'loose');
inside = imrotate(true(size(raw)), angleDeg, 'nearest', 'loose');
R(~inside) = 205;
[r, c] = find(R ~= 205);
r0 = max(min(r) - 10, 1); r1 = min(max(r) + 10, size(R, 1));
c0 = max(min(c) - 10, 1); c1 = min(max(c) + 10, size(R, 2));
R = R(r0:r1, c0:c1);
imwrite(R, outFile);
fprintf('wrote %s (%d x %d)\n', outFile, size(R, 2), size(R, 1));
end
