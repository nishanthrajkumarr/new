# Complete coverage on map_v2 (MATLAB)

A MATLAB port of the coverage simulation used in the slides (the Python version was `sim3.py`).

## Files
| File | What it is |
|---|---|
| `coverage_sim.m` | the whole simulation: map → costmap → plan → RPP / DWA → revisit → dock, with one simple live plot (map, polygon, mowed area in green, trail: blue RPP, magenta DWA, orange revisit, red people) |
| `rotate_map.m` | rotates `map_v2.pgm` by 18° so the lawn edges line up with the image axes |
| `map_v2_rot18.pgm` / `.yaml` | the rotated map the polygon coordinates refer to |
| `map_v2.pgm` / `.yaml` | your original SLAM map |

## Run in MATLAB Online
1. Upload this folder to MATLAB Drive, then `cd` into it.
2. Run:
   ```matlab
   r = coverage_sim;                       % live plot
   r = coverage_sim('video', true);        % also writes coverage_sim.mp4
   r = coverage_sim('drawEvery', 100);     % faster: redraw less often
   r = coverage_sim('plot', false);        % no plot, just the numbers
   r = coverage_sim('seed', 7, 'people', 2);
   ```
3. `r` holds the plan (`r.P`, `r.TAG`), every pose (`r.poses`), the coverage grid (`r.cut`), the coverage after the plan alone (`r.cutMain`) and the final fraction (`r.covered`).

Needs the **Image Processing Toolbox** (`bwdist`, `bwareaopen`, `bwlabel`, `imrotate`). Nothing else.

## What each part does
1. **Costmap.** Occupied cells under 12 px are SLAM speckle and are dropped. Unknown islands under 200 px count as free. The robot needs 0.30 m inscribed clearance, and the inflation decays out to 0.55 m.
2. **Polygon.** A custom 19-vertex polygon over the whole lower lawn (546 m²). "Mowable" means the cutter can reach it with the robot centre kept 0.35 m from obstacles (about 518 m²).
3. **Plan.** This follows Fields2Cover's ideas:
   - a headland ring along the polygon edge;
   - a ring around every obstacle inside it;
   - swaths every 0.45 m (0.55 m cutter, so 10 cm of overlap), grouped into boustrophedon cells.
   
   Cells and rings are ordered nearest-first, keeping the best of 100 randomized orders. Every gap and turn is joined with A* on the costmap.
4. **Follow.** Regulated Pure Pursuit, with lookahead 0.6 m on straight swaths and 0.3 m in turns and rings.
5. **People.** Each person walks in about 3 m ahead and stands on a swath until the robot has passed. Once a person is inside the 4 m local costmap and on the path:
   - a local A* detour is planned around them;
   - DWA drives it;
   - RPP takes over once the robot is back on the path.
6. **Revisit.** At the end, the coverage grid is compared with the mowable area. Missed cells are covered greedily by revisit points, visited one by one (up to 3 rounds). Then the robot returns to the dock.

## Notes
- Coordinates are pixels of `map_v2_rot18.pgm`, as `[x y] = [column row]`, 1-based. One cell is 0.05 m.
- If you only have `map_v2.pgm`, `coverage_sim` rotates it for you. MATLAB's rotation can differ from the included file by a pixel, which is harmless here.
- This is a 2D simulation with simple versions of A*, RPP and DWA. It is not Nav2.
- In Python the same setup gave 98.8% coverage after the plan and 100% after revisiting, over about 90 simulated minutes. MATLAB's random numbers differ, so people appear at other places and the numbers should be close but not identical.
